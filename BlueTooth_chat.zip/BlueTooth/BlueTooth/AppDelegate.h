//
//  AppDelegate.h
//  BlueTooth
//
//  Created by coverme on 15/10/30.
//  Copyright (c) 2015年 coverme. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewController.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end


//
//  CentralViewController.h
//  BlueTooth
//
//  Created by coverme on 15/11/2.
//  Copyright (c) 2015年 coverme. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreBluetooth/CoreBluetooth.h>

@interface CentralViewController : UIViewController

@end
